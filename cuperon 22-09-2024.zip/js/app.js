import { mouseOver } from './modules/mouseover.js';
import { offcanvsMenu } from './modules/offcanvasmenu.js';
import { Slider } from './modules/slider.js';
import {Locomotive} from './modules/locotrigger.js'



mouseOver();
offcanvsMenu();
Slider();
Locomotive();